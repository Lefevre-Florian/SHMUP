namespace Com.IsartDigital.SHMUP.Structure.Architecture {

	public enum Languages
	{
		FR = 0,
		EN = 1
	}

}