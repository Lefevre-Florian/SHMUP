namespace Com.IsartDigital.Utils.Events {

	public static class EventTween
	{
		public const string TWEEN_ALL_COMPLETED = "tween_all_completed";
		public const string TWEEN_COMPLETED = "tween_completed";
		public const string TWEEN_STARTED = "tween_started";
		public const string TWEEN_STEP = "tween_step";
	}

}