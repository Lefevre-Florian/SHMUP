namespace Com.IsartDigital.Utils.Events {

	public static class EventSlider
	{
		public const string DRAG_STARTED = "drag_started";
		public const string DRAG_ENDED = "drag_ended";
	}

}