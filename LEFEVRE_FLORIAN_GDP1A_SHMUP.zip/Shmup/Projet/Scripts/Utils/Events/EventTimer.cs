using Godot;
using System;

namespace Com.IsartDigital.Utils.Events {

	public static class EventTimer
	{

		public const string TIMEOUT = "timeout";

	}

}