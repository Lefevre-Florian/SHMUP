namespace Com.IsartDigital.Utils.Events {

	public static class EventAudioStreamPlayer2D
	{
		public const string FINISHED = "finished";
	}

}